如果你想帮助**ECharts**的话，请首先阅读[指导原则](http://echarts.baidu.com)。

If you want to improve **ECharts**,please review the [guideline for contributing](http://echarts.baidu.com) for ECharts Repository.

## 指导原则如下 示例？

- 是什么样的问题，想清楚怎么描述？
- 是自己的问题，不会多了逗号吧？囧
- 是ECharts的问题，console里有奇怪的log？
- 提issue或者群里提问[注意最好提供完整的option，截图，并说明版本]
- 多看文档多实践，多看文档多实践，多看文档多实践。重要的事情说三遍，也想三遍
- 查看一个例子，[issues_demo](https://github.com/SuperZDev/echarts/blob/master/.github/ISSUE_TEMPLATE.md)



