从来没有想过，在线创建一个文件，竟然如此简单顺畅。赞100000000


http://webapps.stackexchange.com/questions/36411/create-a-folder-in-github-via-the-web-interface
